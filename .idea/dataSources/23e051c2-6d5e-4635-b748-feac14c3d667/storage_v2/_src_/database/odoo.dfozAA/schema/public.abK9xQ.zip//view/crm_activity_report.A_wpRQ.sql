create view crm_activity_report
            (id, lead_create_date, date_conversion, date_deadline, date_closed, subtype_id, mail_activity_type_id,
             author_id, date, body, lead_id, user_id, team_id, country_id, company_id, stage_id, partner_id, lead_type,
             active)
as
SELECT m.id,
       l.create_date AS lead_create_date,
       l.date_conversion,
       l.date_deadline,
       l.date_closed,
       m.subtype_id,
       m.mail_activity_type_id,
       m.author_id,
       m.date,
       m.body,
       l.id          AS lead_id,
       l.user_id,
       l.team_id,
       l.country_id,
       l.company_id,
       l.stage_id,
       l.partner_id,
       l.type        AS lead_type,
       l.active
FROM mail_message m
         JOIN crm_lead l ON m.res_id = l.id
WHERE m.model::text = 'crm.lead'::text
  AND (m.mail_activity_type_id IS NOT NULL OR m.subtype_id = 1);

alter table crm_activity_report
    owner to odoo;

